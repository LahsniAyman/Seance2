import React, { useState, useMemo, useEffect } from 'react';
import { createRoot } from 'react-dom/client';
import { 
  ShieldCheck, 
  AlertTriangle, 
  XCircle, 
  Info, 
  BarChart3, 
  User, 
  Wallet, 
  Briefcase, 
  History, 
  Zap,
  ChevronRight,
  TrendingUp,
  FileText,
  Search,
  CheckCircle2,
  Clock
} from 'lucide-react';
import { GoogleGenAI } from "@google/genai";

// --- Types & Interfaces ---

interface CreditData {
  age: number;
  monthlyIncome: number;
  jobStatus: 'CDI' | 'CDD' | 'Independent' | 'Unemployed';
  seniority: number; // in years
  loanAmount: number;
  duration: number; // in months
  existingDebts: number;
  savings: number;
  paymentIncidents: number;
}

interface ScoringResult {
  score: number;
  status: 'Approved' | 'Manual' | 'Rejected';
  riskLevel: 'Low' | 'Medium' | 'High';
  dtiRatio: number; // Debt-to-income
  loanToIncome: number;
  probabilities: {
    default: number;
    solvable: number;
  };
}

// --- Utils & Models ---

/**
 * Heuristic model representing the logic of an XGBoost/Random Forest model.
 * In a real-world scenario, this would be a call to a Python API serving a serialized model.
 */
const calculateCreditScore = (data: CreditData): ScoringResult => {
  const { age, monthlyIncome, jobStatus, seniority, loanAmount, duration, existingDebts, savings, paymentIncidents } = data;

  // 1. Feature Engineering
  const dtiRatio = ((existingDebts + (loanAmount / duration)) / monthlyIncome) * 100;
  const loanToIncome = (loanAmount / (monthlyIncome * 12)) * 100;
  
  let baseScore = 600; // Starting neutral score

  // 2. Weighting Factors (Simplified Model Weights)
  
  // DTI impact (Crucial)
  if (dtiRatio > 45) baseScore -= 250;
  else if (dtiRatio > 33) baseScore -= 100;
  else if (dtiRatio < 20) baseScore += 50;

  // Payment Incidents (Fatal)
  baseScore -= (paymentIncidents * 150);

  // Job Status & Seniority
  if (jobStatus === 'CDI') {
    baseScore += 80;
    if (seniority > 5) baseScore += 50;
    if (seniority < 1) baseScore -= 30;
  } else if (jobStatus === 'CDD') {
    baseScore -= 50;
  } else if (jobStatus === 'Unemployed') {
    baseScore -= 300;
  }

  // Savings (Buffer)
  const savingsMonths = savings / monthlyIncome;
  if (savingsMonths > 6) baseScore += 100;
  else if (savingsMonths > 2) baseScore += 40;
  else baseScore -= 50;

  // Age (Standard demographic risk)
  if (age < 25) baseScore -= 40;
  else if (age > 60) baseScore -= 20;

  // Clamp Score
  const finalScore = Math.max(0, Math.min(1000, baseScore));

  // Decision Rules
  let status: 'Approved' | 'Manual' | 'Rejected';
  let riskLevel: 'Low' | 'Medium' | 'High';

  if (finalScore >= 700) {
    status = 'Approved';
    riskLevel = 'Low';
  } else if (finalScore >= 400) {
    status = 'Manual';
    riskLevel = 'Medium';
  } else {
    status = 'Rejected';
    riskLevel = 'High';
  }

  return {
    score: finalScore,
    status,
    riskLevel,
    dtiRatio,
    loanToIncome,
    probabilities: {
      default: (1000 - finalScore) / 1000,
      solvable: finalScore / 1000
    }
  };
};

// --- Components ---

const ProgressBar = ({ value, max, color }: { value: number, max: number, color: string }) => (
  <div className="w-full bg-slate-100 rounded-full h-2">
    <div 
      className={`h-2 rounded-full transition-all duration-1000 ${color}`} 
      style={{ width: `${(value / max) * 100}%` }}
    ></div>
  </div>
);

const App = () => {
  const [formData, setFormData] = useState<CreditData>({
    age: 35,
    monthlyIncome: 3500,
    jobStatus: 'CDI',
    seniority: 4,
    loanAmount: 15000,
    duration: 36,
    existingDebts: 400,
    savings: 12000,
    paymentIncidents: 0,
  });

  const [result, setResult] = useState<ScoringResult | null>(null);
  const [explanation, setExplanation] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);
  const [view, setView] = useState<'agent' | 'dashboard'>('agent');

  const ai = useMemo(() => new GoogleGenAI({ apiKey: process.env.API_KEY }), []);

  const handleScoring = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    const scoringResult = calculateCreditScore(formData);
    setResult(scoringResult);

    try {
      // Explainable AI using Gemini
      const prompt = `
        En tant qu'expert en gestion des risques bancaires (Risk Management), analyse le profil de crédit suivant et explique la décision de l'Agent IA.
        
        PROFIL CLIENT:
        - Âge: ${formData.age} ans
        - Revenu: ${formData.monthlyIncome}€/mois
        - Emploi: ${formData.jobStatus} (Ancienneté: ${formData.seniority} ans)
        - Crédit demandé: ${formData.loanAmount}€ sur ${formData.duration} mois
        - Dettes existantes: ${formData.existingDebts}€/mois
        - Épargne: ${formData.savings}€
        - Incidents de paiement: ${formData.paymentIncidents}
        
        RÉSULTAT DE L'ALGORITHME:
        - Score: ${scoringResult.score}/1000
        - Décision: ${scoringResult.status}
        - Niveau de Risque: ${scoringResult.riskLevel}
        - Taux d'endettement: ${scoringResult.dtiRatio.toFixed(2)}%
        
        MISSION:
        1. Justifie le score en citant les variables les plus impactantes (Explainable AI).
        2. Évalue la solidité du dossier par rapport aux standards bancaires (Bâle III).
        3. Identifie les signaux d'alerte (Red Flags) ou les points forts.
        4. Donne une recommandation finale courte.
        
        Réponds de manière structurée avec un ton professionnel et pédagogique.
      `;

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
      });

      setExplanation(response.text || "Impossible de générer l'explication.");
    } catch (error) {
      console.error("Gemini API Error:", error);
      setExplanation("Erreur lors de la génération de l'analyse XAI.");
    } finally {
      setIsLoading(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Approved': return 'text-emerald-600 bg-emerald-50 border-emerald-100';
      case 'Manual': return 'text-amber-600 bg-amber-50 border-amber-100';
      case 'Rejected': return 'text-rose-600 bg-rose-50 border-rose-100';
      default: return 'text-slate-600 bg-slate-50 border-slate-100';
    }
  };

  return (
    <div className="min-h-screen pb-12">
      {/* Header */}
      <nav className="gradient-bg text-white py-4 px-8 flex justify-between items-center shadow-xl sticky top-0 z-50">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-blue-500 rounded-lg">
            <ShieldCheck size={28} />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight">RiskGuard AI</h1>
            <p className="text-xs text-blue-200 uppercase tracking-widest font-semibold">Automated Credit Scoring Agent</p>
          </div>
        </div>
        <div className="flex items-center gap-6">
          <button 
            onClick={() => setView('agent')}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${view === 'agent' ? 'bg-white/10 text-white' : 'text-slate-400 hover:text-white'}`}
          >
            Agent Scoring
          </button>
          <button 
            onClick={() => setView('dashboard')}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${view === 'dashboard' ? 'bg-white/10 text-white' : 'text-slate-400 hover:text-white'}`}
          >
            Analyst Dashboard
          </button>
          <div className="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center border border-slate-600">
            <User size={18} />
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-6 mt-8">
        {view === 'agent' ? (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            
            {/* Left: Input Form */}
            <div className="lg:col-span-5">
              <div className="glass-panel rounded-2xl p-6 shadow-sm border border-slate-200">
                <div className="flex items-center gap-2 mb-6 text-slate-800">
                  <BarChart3 size={20} className="text-blue-600" />
                  <h2 className="text-lg font-bold">Paramètres de la demande</h2>
                </div>
                
                <form onSubmit={handleScoring} className="space-y-5">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-500 uppercase">Âge du Client</label>
                      <input 
                        type="number" 
                        value={formData.age}
                        onChange={(e) => setFormData({...formData, age: Number(e.target.value)})}
                        className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all text-sm"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-500 uppercase">Situation Professionnelle</label>
                      <select 
                        value={formData.jobStatus}
                        onChange={(e) => setFormData({...formData, jobStatus: e.target.value as any})}
                        className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all text-sm appearance-none bg-white"
                      >
                        <option value="CDI">CDI</option>
                        <option value="CDD">CDD</option>
                        <option value="Independent">Indépendant</option>
                        <option value="Unemployed">Sans Emploi</option>
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-500 uppercase">Revenu Mensuel Net (€)</label>
                      <input 
                        type="number" 
                        value={formData.monthlyIncome}
                        onChange={(e) => setFormData({...formData, monthlyIncome: Number(e.target.value)})}
                        className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all text-sm"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-500 uppercase">Ancienneté (Années)</label>
                      <input 
                        type="number" 
                        value={formData.seniority}
                        onChange={(e) => setFormData({...formData, seniority: Number(e.target.value)})}
                        className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all text-sm"
                      />
                    </div>
                  </div>

                  <hr className="border-slate-100" />

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-500 uppercase">Montant du Crédit (€)</label>
                      <input 
                        type="number" 
                        value={formData.loanAmount}
                        onChange={(e) => setFormData({...formData, loanAmount: Number(e.target.value)})}
                        className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all text-sm font-semibold"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-500 uppercase">Durée (Mois)</label>
                      <input 
                        type="number" 
                        value={formData.duration}
                        onChange={(e) => setFormData({...formData, duration: Number(e.target.value)})}
                        className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all text-sm"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-500 uppercase">Dettes Existantes (€/m)</label>
                      <input 
                        type="number" 
                        value={formData.existingDebts}
                        onChange={(e) => setFormData({...formData, existingDebts: Number(e.target.value)})}
                        className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all text-sm text-rose-600"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-500 uppercase">Épargne Totale (€)</label>
                      <input 
                        type="number" 
                        value={formData.savings}
                        onChange={(e) => setFormData({...formData, savings: Number(e.target.value)})}
                        className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all text-sm text-emerald-600"
                      />
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-500 uppercase">Incidents de Paiement (12 derniers mois)</label>
                    <input 
                      type="number" 
                      value={formData.paymentIncidents}
                      onChange={(e) => setFormData({...formData, paymentIncidents: Number(e.target.value)})}
                      className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-rose-500 focus:border-transparent outline-none transition-all text-sm"
                    />
                  </div>

                  <button 
                    type="submit" 
                    disabled={isLoading}
                    className="w-full py-3.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-lg shadow-blue-200 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    {isLoading ? (
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    ) : (
                      <>
                        <Zap size={18} />
                        Lancer l'Analyse Agent AI
                      </>
                    )}
                  </button>
                </form>
              </div>
            </div>

            {/* Right: Results & XAI */}
            <div className="lg:col-span-7 space-y-8">
              {!result && !isLoading && (
                <div className="h-full flex flex-col items-center justify-center text-center p-12 glass-panel rounded-2xl border-dashed border-2 border-slate-300">
                  <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mb-4 text-slate-400">
                    <TrendingUp size={32} />
                  </div>
                  <h3 className="text-slate-600 font-medium">Prêt pour l'analyse</h3>
                  <p className="text-slate-400 text-sm max-w-xs mx-auto mt-2">Remplissez les données client à gauche pour générer un score de crédit et une analyse de risque.</p>
                </div>
              )}

              {isLoading && (
                <div className="animate-pulse space-y-6">
                  <div className="h-48 bg-slate-200 rounded-2xl"></div>
                  <div className="h-64 bg-slate-200 rounded-2xl"></div>
                </div>
              )}

              {result && !isLoading && (
                <>
                  {/* Score Card */}
                  <div className="glass-panel rounded-2xl overflow-hidden shadow-sm">
                    <div className="p-6 bg-white border-b border-slate-100 flex justify-between items-center">
                      <div>
                        <h2 className="text-lg font-bold text-slate-800">Décision Automatisée</h2>
                        <p className="text-xs text-slate-500">Généré le {new Date().toLocaleDateString()} à {new Date().toLocaleTimeString()}</p>
                      </div>
                      <div className={`px-4 py-1.5 rounded-full border text-xs font-bold uppercase tracking-wider ${getStatusColor(result.status)}`}>
                        {result.status === 'Approved' && 'Acceptation Auto'}
                        {result.status === 'Manual' && 'Revue Manuelle'}
                        {result.status === 'Rejected' && 'Refus Auto'}
                      </div>
                    </div>
                    
                    <div className="p-8 grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
                      <div className="relative flex justify-center items-center">
                        <svg className="w-48 h-48 transform -rotate-90">
                          <circle cx="96" cy="96" r="88" stroke="currentColor" strokeWidth="12" fill="transparent" className="text-slate-100" />
                          <circle 
                            cx="96" 
                            cy="96" 
                            r="88" 
                            stroke="currentColor" 
                            strokeWidth="12" 
                            fill="transparent" 
                            strokeDasharray={552.92}
                            strokeDashoffset={552.92 * (1 - result.score / 1000)}
                            className={`transition-all duration-1000 ease-out ${result.score > 700 ? 'text-emerald-500' : result.score > 400 ? 'text-amber-500' : 'text-rose-500'}`}
                          />
                        </svg>
                        <div className="absolute inset-0 flex flex-col items-center justify-center">
                          <span className="text-5xl font-black text-slate-800 tracking-tight">{result.score}</span>
                          <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Score Crédit</span>
                        </div>
                      </div>

                      <div className="space-y-6">
                        <div>
                          <div className="flex justify-between text-xs font-bold text-slate-500 uppercase mb-2">
                            <span>Taux d'endettement</span>
                            <span className={result.dtiRatio > 33 ? 'text-rose-500' : 'text-emerald-500'}>{result.dtiRatio.toFixed(1)}%</span>
                          </div>
                          <ProgressBar value={Math.min(100, result.dtiRatio)} max={100} color={result.dtiRatio > 33 ? 'bg-rose-500' : 'bg-emerald-500'} />
                        </div>
                        <div>
                          <div className="flex justify-between text-xs font-bold text-slate-500 uppercase mb-2">
                            <span>Probabilité de Défaut</span>
                            <span className="text-slate-800">{(result.probabilities.default * 100).toFixed(1)}%</span>
                          </div>
                          <ProgressBar value={result.probabilities.default * 100} max={100} color="bg-slate-400" />
                        </div>
                        <div className="pt-2">
                          <div className="flex items-center gap-2 text-sm text-slate-600">
                            <Info size={16} className="text-blue-500" />
                            <span>Risque évalué comme : <strong>{result.riskLevel === 'Low' ? 'Faible' : result.riskLevel === 'Medium' ? 'Modéré' : 'Critique'}</strong></span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Explainable AI Panel */}
                  <div className="glass-panel rounded-2xl p-6 shadow-sm border border-slate-200">
                    <div className="flex items-center gap-3 mb-6">
                      <div className="p-2 bg-purple-100 text-purple-600 rounded-lg">
                        <Zap size={20} />
                      </div>
                      <div>
                        <h2 className="text-lg font-bold text-slate-800">Explainable AI (XAI)</h2>
                        <p className="text-xs text-slate-500">Interprétation cognitive de l'agent IA sur le modèle de scoring</p>
                      </div>
                    </div>

                    <div className="prose prose-slate max-w-none">
                      <div className="bg-slate-50/50 p-6 rounded-xl border border-slate-100 whitespace-pre-wrap text-sm leading-relaxed text-slate-700 italic">
                        {explanation}
                      </div>
                    </div>

                    <div className="mt-6 flex flex-wrap gap-4">
                      <div className="flex items-center gap-2 px-3 py-1.5 bg-blue-50 rounded-lg border border-blue-100 text-[10px] font-bold text-blue-700 uppercase">
                        <CheckCircle2 size={12} /> Bâle III Compliant
                      </div>
                      <div className="flex items-center gap-2 px-3 py-1.5 bg-purple-50 rounded-lg border border-purple-100 text-[10px] font-bold text-purple-700 uppercase">
                        <Zap size={12} /> Gemini Optimized
                      </div>
                      <div className="flex items-center gap-2 px-3 py-1.5 bg-slate-50 rounded-lg border border-slate-200 text-[10px] font-bold text-slate-500 uppercase">
                        <ShieldCheck size={12} /> Audit Trail Logged
                      </div>
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>
        ) : (
          /* Dashboard View */
          <div className="space-y-8 animate-in fade-in duration-500">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              {[
                { label: 'Demandes (24h)', value: '1,284', change: '+12%', icon: FileText, color: 'text-blue-600', bg: 'bg-blue-50' },
                { label: 'Taux Approbation', value: '64.2%', change: '-2.1%', icon: CheckCircle2, color: 'text-emerald-600', bg: 'bg-emerald-50' },
                { label: 'Alertes Risque', value: '42', change: '+5', icon: AlertTriangle, color: 'text-amber-600', bg: 'bg-amber-50' },
                { label: 'Temps Moyen Décision', value: '1.2s', change: '-48%', icon: Clock, color: 'text-purple-600', bg: 'bg-purple-50' },
              ].map((stat, idx) => (
                <div key={idx} className="glass-panel p-6 rounded-2xl border border-slate-200 shadow-sm">
                  <div className="flex justify-between items-start mb-4">
                    <div className={`p-2 rounded-lg ${stat.bg} ${stat.color}`}>
                      <stat.icon size={20} />
                    </div>
                    <span className={`text-xs font-bold ${stat.change.startsWith('+') ? 'text-emerald-600' : 'text-rose-600'}`}>
                      {stat.change}
                    </span>
                  </div>
                  <h4 className="text-2xl font-black text-slate-800">{stat.value}</h4>
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mt-1">{stat.label}</p>
                </div>
              ))}
            </div>

            <div className="glass-panel rounded-2xl border border-slate-200 overflow-hidden">
              <div className="p-6 bg-white border-b border-slate-100 flex justify-between items-center">
                <h3 className="font-bold text-slate-800">Files d'attente récentes (Batch Processing)</h3>
                <div className="flex gap-2">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                    <input type="text" placeholder="Rechercher un dossier..." className="pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500" />
                  </div>
                </div>
              </div>
              <table className="w-full text-left border-collapse">
                <thead className="bg-slate-50 text-[10px] uppercase font-bold text-slate-500 tracking-wider">
                  <tr>
                    <th className="px-6 py-4">Candidat ID</th>
                    <th className="px-6 py-4">Score AI</th>
                    <th className="px-6 py-4">DTI Ratio</th>
                    <th className="px-6 py-4">Montant</th>
                    <th className="px-6 py-4">Statut</th>
                    <th className="px-6 py-4">Action</th>
                  </tr>
                </thead>
                <tbody className="text-sm divide-y divide-slate-100">
                  {[
                    { id: 'CRD-8291', score: 842, dti: '12%', amount: '45,000€', status: 'Approved' },
                    { id: 'CRD-3301', score: 320, dti: '48%', amount: '12,500€', status: 'Rejected' },
                    { id: 'CRD-4922', score: 580, dti: '31%', amount: '22,000€', status: 'Manual' },
                    { id: 'CRD-1102', score: 710, dti: '22%', amount: '5,000€', status: 'Approved' },
                    { id: 'CRD-9003', score: 410, dti: '35%', amount: '35,000€', status: 'Manual' },
                  ].map((row, idx) => (
                    <tr key={idx} className="hover:bg-slate-50 transition-colors">
                      <td className="px-6 py-4 font-mono font-bold text-slate-600">{row.id}</td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <span className={`w-2 h-2 rounded-full ${row.score > 700 ? 'bg-emerald-500' : row.score > 400 ? 'bg-amber-500' : 'bg-rose-500'}`}></span>
                          <span className="font-bold">{row.score}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-slate-500">{row.dti}</td>
                      <td className="px-6 py-4 font-medium text-slate-700">{row.amount}</td>
                      <td className="px-6 py-4">
                        <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase ${getStatusColor(row.status)} border`}>
                          {row.status}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <button className="p-2 hover:bg-slate-200 rounded-lg text-slate-400 transition-colors">
                          <ChevronRight size={18} />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <div className="p-4 bg-slate-50 border-t border-slate-100 text-center">
                <button className="text-xs font-bold text-blue-600 hover:text-blue-800 transition-colors">Voir tous les dossiers (1,284)</button>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Footer Info */}
      <footer className="max-w-7xl mx-auto px-6 mt-12 grid grid-cols-1 md:grid-cols-3 gap-8 text-slate-400 text-xs border-t border-slate-200 pt-8">
        <div>
          <h5 className="font-bold text-slate-600 mb-3 uppercase tracking-widest">Compliance & Sécurité</h5>
          <p className="leading-relaxed">Système certifié RGPD et conforme aux directives de l'ACPR pour l'utilisation de l'IA dans les services financiers. Les données sont chiffrées en transit et au repos (AES-256).</p>
        </div>
        <div>
          <h5 className="font-bold text-slate-600 mb-3 uppercase tracking-widest">Modèles Supportés</h5>
          <p className="leading-relaxed">Intégration native de modèles Gradient Boosting (XGBoost), Random Forest et Régression Logistique. Pipeline de validation continue intégré (Backtesting mensuel).</p>
        </div>
        <div>
          <h5 className="font-bold text-slate-600 mb-3 uppercase tracking-widest">Monitoring AI</h5>
          <p className="leading-relaxed">Détection automatique de dérive de données (Data Drift) et de biais algorithmiques. Monitoring en temps réel de l'impact business sur le taux de défaut global.</p>
        </div>
      </footer>
    </div>
  );
};

const root = createRoot(document.getElementById('root')!);
root.render(<App />);